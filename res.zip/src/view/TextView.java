package view;

/**
 * This is class that represents a Concrete Text view for the program.
 */
public class TextView {
}
