package view;

/**
 * This is clas that represents a Concrete Graphic view for the program.
 */
public class GraphicView {
}
